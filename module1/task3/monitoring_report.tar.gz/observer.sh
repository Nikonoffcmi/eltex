#!/bin/bash

CONFIG_FILE="/home/user1/config.txt"
LOG_FILE="observer.log"

# Проверяем существование конфигурационного файла
if [ ! -f "$CONFIG_FILE" ]; then
    echo "Ошибка: Конфигурационный файл '$CONFIG_FILE' не найден" >&2
    exit 2
fi

while IFS= read -r script || [ -n "$script" ]; do
    # Пропускаем пустые строки и комментарии
    script=$(echo "$script" | sed 's/#.*//; s/^[[:space:]]*//; s/[[:space:]]*$//')
    if [ -z "$script" ]; then
	continue
    fi

    # Проверяем существование файла скрипта
    if [ ! -f "$script" ]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Ошибка: Скрипт '$script' не существует" >> "$LOG_FILE"
        continue
    fi

    # Проверяем выполняется ли скрипт
    if ! pgrep -f "$script" > /dev/null; then
        nohup /bin/bash "$script" > /dev/null 2>&1 &
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] Запущен скрипт: $script" >> "$LOG_FILE"
    fi
    echo "vrssfs"
done < "$CONFIG_FILE"
    
