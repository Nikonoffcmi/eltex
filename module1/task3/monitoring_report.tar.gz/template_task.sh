#!/bin/bash

script_name=$(basename "$0")

report_file="report_${script_name}.log"

echo "[$$] $(date "+%Y-%m-%d %H:%M:%S") Скрипт запущен" >> "$report_file"

sleep_time=$(( RANDOM % 1771 + 30 ))

sleep $sleep_time

minutes=$(echo "scale=2; $sleep_time / 60" | bc)

echo "[$$] $(date "+%Y-%m-%d %H:%M:%S") Скрипт завершился, работал $minutes минут" >> "$report_file"
